package com.example.report;

import java.util.Date;


public class Customer {

    private Date date;
    private String name;
    private String referenceID;
    private String product;
    private double cost;
    private float quantity;
    private double total;

    public Customer(Date date, String name, String referenceID, String product, double cost, float quantity, double total) {
        this.date = date;
        this.name = name;
        this.referenceID = referenceID;
        this.product = product;
        this.cost = cost;
        this.quantity = quantity;
        this.total = total;
    }

    public Date getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getReferenceID() {
        return referenceID;
    }

    public String getProduct() {
        return product;
    }

    public double getCost() {
        return cost;
    }

    public float getQuantity() {
        return quantity;
    }

    public double getTotal() {
        return total;
    }
}

