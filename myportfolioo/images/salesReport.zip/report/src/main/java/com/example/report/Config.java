package com.example.report;

public class Config {
}
