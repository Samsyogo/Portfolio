package com.example.report;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Arrays;
import java.util.Date;

@Controller
@RequestMapping("/report")
public class CustomerController {

    @GetMapping("/sales-report")
    String getCustomer( Model model ) {
        model.addAttribute("Customer", Arrays.asList(
                new Customer(new Date(),"SAMSON OYOGO", "A0001","FITZ", 500000.00,2,
                1000000.00 ),
                new Customer(new Date(),"SAMUEL TYLER", "A0002","RAV4", 1800000.00,1,
                500000.00 ),
                new Customer(new Date(),"DAVID COLE", "A0003","CROWN", 2000000.00,1,
                        2000000.00 ),
                new Customer(new Date(),"CHRIS JAMES", "A0004","DEMIO", 800000.00,3,
                        2400000.00 ),
                new Customer(new Date(),"DAVID BRIGHTON", "A0005","V8", 5000000.00,1,
                        5000000.00 )

                        ));

        return "index";

    }
}

